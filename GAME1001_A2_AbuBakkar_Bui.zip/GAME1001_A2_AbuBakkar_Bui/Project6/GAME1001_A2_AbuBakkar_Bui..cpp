//This is the work of Abu Bakkar and Bui Phuc Thong

#include <iostream>
#include <string>
using namespace std;

class weapons {
public:
    string name;
    string sound;
    double price;
    int ammo;
    bool own;
};

int main() {
    int choiceMenu{}, choiceBuy, i;
    double cash = 100000;
    string playerSlot[6];
    int count = 1;

    //creation of owbjects of 5 weapons
    weapons weap1;
    weap1.name = "AK-47";
    weap1.sound = "rat tah tah";
    weap1.ammo = 50;
    weap1.price = 10000;
    weap1.own = false;

    weapons weap2;
    weap2.name = "Gloc-9";
    weap2.sound = "Brrrrrrrrrrt";
    weap2.ammo = 12;
    weap2.price = 6000;
    weap2.own = false;

    weapons weap3;
    weap3.name = "Colt 45";
    weap3.sound = "Ping";
    weap3.ammo = 5;
    weap3.price = 5000;
    weap3.own = false;

    weapons weap4;
    weap4.name = "Shotgun";
    weap4.sound = "Booom";
    weap4.ammo = 2;
    weap4.price = 10000;
    weap4.own = false;

    weapons weap5;
    weap5.name = "Sniper";
    weap5.sound = "Pew";
    weap5.ammo = 6;
    weap5.price = 50000;
    weap5.own = false;

    //Loop for the entire game  
    while (choiceMenu != 4) {

        cout << "*************** S T O R E M E N U ***************" << endl;
        cout << "Press 1 to BUY WEAPON" << endl;
        cout << "Press 2 to CHECK BALANCE" << endl;
        cout << "Press 3 to EXIT STORE" << endl;
        cout << "*************************************************" << endl;
        cout << "Choice: ";
        cin >> choiceMenu;

        //selection of menu and its functions
        switch (choiceMenu) {

        case 1:
            //Display of the 5 weapons to select
            cout << "\n**Choose your weapon**";
            cout << "\n 1. " << weap1.name;
            cout << "\n 2. " << weap2.name;
            cout << "\n 3. " << weap3.name;
            cout << "\n 4. " << weap4.name;
            cout << "\n 5. " << weap5.name;
            cout << "\n************************" << endl;
            cout << "\nWhich weapon you want to buy: ";
            cin >> choiceBuy;

            switch (choiceBuy) {
                //Selection of each weapon and its attributes
            case 1:

                if (weap1.own == true) {
                    cout << "You have this weapon already" << endl << endl;
                    break;
                }
                else if (weap1.own == false && weap1.price > cash) {
                    cout << "You dont have enough money" << endl << endl;
                    break;
                }
                else {
                    cout << "Successfully Purchased" << endl << endl;
                    cash -= weap1.price;
                    playerSlot[count] = weap1.sound;
                    weap1.own = true;
                    count++;
                    break;
                }
                break;

            case 2:
                if (weap2.own == true) {
                    cout << "You have this weapon already" << endl << endl;
                    break;
                }
                else if (weap2.own == false && weap2.price > cash) {
                    cout << "You dont have enough money" << endl << endl;
                    break;
                }
                else {
                    cout << "Successfully Purchased" << endl << endl;
                    cash -= weap2.price;
                    playerSlot[count] = weap2.sound;
                    weap2.own = true;
                    count++;
                    break;
                }
                break;

            case 3:
                if (weap3.own == true) {
                    cout << "You have this weapon already" << endl << endl;
                    break;
                }
                else if (weap3.own == false && weap3.price > cash) {
                    cout << "You dont have enough money" << endl << endl;
                    break;
                }
                else {
                    cout << "Successfully Purchased" << endl << endl;
                    cash -= weap3.price;
                    playerSlot[count] = weap3.sound;
                    weap3.own = true;
                    count++;
                    break;
                }
                break;

            case 4:
                if (weap4.own == true) {
                    cout << "You have this weapon already" << endl << endl;
                    break;
                }
                else if (weap4.own == false && weap4.price > cash) {
                    cout << "You dont have enough money" << endl << endl;
                    break;
                }
                else {
                    cout << "Successfully Purchased" << endl << endl;
                    cash -= weap4.price;
                    playerSlot[count] = weap4.sound;
                    weap4.own = true;
                    count++;
                    break;
                }
                break;

            case 5:
                if (weap5.own == true) {
                    cout << "You have this weapon already" << endl << endl;
                    break;
                }
                else if (weap5.own == false && weap5.price > cash) {
                    cout << "You dont have enough money" << endl << endl;
                    break;
                }
                else {
                    cout << "Successfully Purchased" << endl << endl;
                    cash -= weap5.price;
                    playerSlot[count] = weap5.sound;
                    weap5.own = true;
                    count++;
                    break;
                }
                break;
            }
            break;
            //checking of balance for the player
        case 2:
            cout << "Player balance is: " << cash << endl;
            break;
            //to exit the Menu and continue to simulation
        case 3:
            if (count != 1) {
                choiceMenu = 4;
                break;
            }
            cout << "You need to buy atleast 1 weapon" << endl;
        }
    }
    //Simulation loop for the weapons
    cout << "Simulation Loop enter 1 - 5 to switch weapon" << endl;
    cin >> i;
    while (i < 6) {
        if (i < 6) {
            cout << playerSlot[i] << endl;
            cin >> i;
        }
        else
            break;
    }
}